export class Student{
  id: number;
  code: string;
  name: string;
  
}
