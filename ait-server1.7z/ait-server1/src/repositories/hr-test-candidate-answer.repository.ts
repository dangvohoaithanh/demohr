import { DefaultCrudRepository, juggler } from '@loopback/repository';
import { HrTestCandidateAnswer } from '../models';
import { inject } from '@loopback/core';

export class HrTestCandidateAnswerRepository extends DefaultCrudRepository<
  HrTestCandidateAnswer,
  typeof HrTestCandidateAnswer.prototype.candidateCode
  > {
  constructor(
    @inject('datasources.ait') protected datasource: juggler.DataSource,
  ) {
    super(HrTestCandidateAnswer, datasource);
  }
}
