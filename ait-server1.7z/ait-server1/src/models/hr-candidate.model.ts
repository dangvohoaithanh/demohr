import {Entity, model, property} from '@loopback/repository';

@model({name: 'hr_candidate'})
export class HrCandidate extends Entity {
  @property({
    type: 'string',
    id: true,
    required: true,
  })
  code: string;

  @property({
    type: 'string',
  })
  name?: string;

  @property({
    type: 'string',
  })
  email?: string;

  @property({
    type: 'string',
  })
  phone?: string;

  @property({
    type: 'string',
  })
  position?: string;

  @property({
    type: 'string',
  })
  testTemplate?: string;

  @property({
    type: 'string',
  })
  testResult?: string;

  @property({
    type: 'string',
  })
  username?: string;

  @property({
    type: 'string',
  })
  password?: string;

  constructor(data?: Partial<HrCandidate>) {
    super(data);
  }
}
