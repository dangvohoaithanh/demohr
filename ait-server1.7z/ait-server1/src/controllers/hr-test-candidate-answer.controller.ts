import {Filter, Where, repository} from '@loopback/repository';
import {
  post,
  param,
  get,
  patch,
  del,
  requestBody
} from '@loopback/rest';
import {HrTestCandidateAnswer} from '../models';
import {HrTestCandidateAnswerRepository} from '../repositories';

export class HrTestCandidateAnswerController {
  constructor(
    @repository(HrTestCandidateAnswerRepository)
    public hrTestCandidateAnswerRepository : HrTestCandidateAnswerRepository,
  ) {}

  @post('/hr-test-candidate-answers')
  async create(@requestBody() obj: HrTestCandidateAnswer)
    : Promise<HrTestCandidateAnswer> {
    return await this.hrTestCandidateAnswerRepository.create(obj);
  }

  @get('/hr-test-candidate-answers/count')
  async count(@param.query.string('where') where?: Where): Promise<number> {
    return await this.hrTestCandidateAnswerRepository.count(where);
  }

  @get('/hr-test-candidate-answers')
  async find(@param.query.string('filter') filter?: Filter)
    : Promise<HrTestCandidateAnswer[]> {
    return await this.hrTestCandidateAnswerRepository.find(filter);
  }

  @patch('/hr-test-candidate-answers')
  async updateAll(
    @requestBody() obj: HrTestCandidateAnswer,
    @param.query.string('where') where?: Where
  ): Promise<number> {
    return await this.hrTestCandidateAnswerRepository.updateAll(obj, where);
  }

  @get('/hr-test-candidate-answers/{id}')
  async findById(@param.path.string('id') id: string): Promise<HrTestCandidateAnswer> {
    return await this.hrTestCandidateAnswerRepository.findById(id);
  }

  @patch('/hr-test-candidate-answers/{id}')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody() obj: HrTestCandidateAnswer
  ): Promise<boolean> {
    return await this.hrTestCandidateAnswerRepository.updateById(id, obj);
  }

  @del('/hr-test-candidate-answers/{id}')
  async deleteById(@param.path.string('id') id: string): Promise<boolean> {
    return await this.hrTestCandidateAnswerRepository.deleteById(id);
  }
}
