export * from './ping.controller';
export * from './hr-candidate.controller';
export * from './m-class.controller';
export * from './hr-test-template.controller';
export * from './hr-test-template-detail.controller';export * from './hr-answer.controller';
export * from './hr-question.controller';
export * from './hr-test-candidate.controller';
export * from './hr-test-candidate-answer.controller';
export * from './hr-test-candidate-question.controller';
