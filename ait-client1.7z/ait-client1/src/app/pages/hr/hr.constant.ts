export enum CLASS {
  POSITION = '0001',
  QUESTION_CATEGORY = '0002'
}
export enum API_URL {
  M_CLASS_GET = '/m-classes',
  HR_TEST_TEMPLATE_GET = '/hr-test-templates',
  HR_CANDIDATE_GET = '/hr-candidates'
}
