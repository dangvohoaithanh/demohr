import { Entity, model, property, hasMany } from '@loopback/repository';
import { HrAnswer } from './hr-answer.model'

@model({ name: 'hr_question' })
export class HrQuestion extends Entity {
  @property({
    type: 'number',
    id: true,
    required: true,
  })
  id: number;

  @property({
    type: 'string',
    required: true,
  })
  category: string;

  @property({
    type: 'string',
    required: true,
  })
  level: string;

  @property({
    type: 'string',
    required: true,
  })
  content: string;

  @property({
    type: 'string',
  })
  image?: string;

  @property({
    type: 'string',
  })
  templatecode?: string;

  @property({
    type: 'boolean',
  })
  activeflag?: boolean;

  @hasMany(HrAnswer, { keyTo: 'questionid' })
  hrAnswers?: HrAnswer[];

  constructor(data?: Partial<HrQuestion>) {
    super(data);
  }
}
