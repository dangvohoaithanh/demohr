export * from './hr-candidate.model';
export * from './m-class.model';
export * from './hr-test-template.model';
export * from './hr-test-template-detail.model';
export * from './hr-answer.model';
export * from './hr-question.model';
