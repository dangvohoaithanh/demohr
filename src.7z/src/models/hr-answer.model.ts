import { Entity, model, property } from '@loopback/repository';

@model({ name: 'hr_answer' })
export class HrAnswer extends Entity {
  @property({
    type: 'number',
    id: true,
    required: true,
  })
  id: number;

  @property({
    type: 'string',
  })
  content?: string;

  @property({
    type: 'string',
  })
  image?: string;

  @property({
    type: 'number',
    required: true,
  })
  questionid: number;

  @property({
    type: 'boolean',
  })
  correct?: boolean;

  constructor(data?: Partial<HrAnswer>) {
    super(data);
  }



}
