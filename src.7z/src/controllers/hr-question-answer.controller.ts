import { post, param, requestBody } from '@loopback/rest';
import { HrQuestionRepository } from '../repositories/';
import { HrQuestion, HrAnswer } from '../models/';
import { repository } from '@loopback/repository';

export class CustomerOrdersController {
  constructor(
    @repository(HrQuestionRepository)
    protected hrquestionRepository: HrQuestionRepository,
  ) { }

  @post('/hr-questions/{id}/answer')
  async createOrder(
    @param.path.number('id') questionid: typeof HrQuestion.prototype.id,
    @requestBody() answerData: HrAnswer,
  ): Promise<HrAnswer> {
    return await this.hrquestionRepository.hrAnswers(questionid).create(answerData);
  }
}
