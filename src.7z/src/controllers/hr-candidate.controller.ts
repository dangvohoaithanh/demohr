import {Filter, Where, repository} from '@loopback/repository';
import {post, param, get, patch, del, requestBody} from '@loopback/rest';
import {HrCandidate} from '../models';
import {HrCandidateRepository} from '../repositories';

export class HrCandidateController {
  constructor(
    @repository(HrCandidateRepository)
    public hrCandidateRepository: HrCandidateRepository,
  ) {}

  @post('/hr-candidates')
  async create(@requestBody() obj: HrCandidate): Promise<HrCandidate> {
    return await this.hrCandidateRepository.create(obj);
  }

  @get('/hr-candidates/count')
  async count(@param.query.string('where') where?: Where): Promise<number> {
    return await this.hrCandidateRepository.count(where);
  }

  @get('/hr-candidates')
  async find(
    @param.query.string('filter') filter?: Filter,
  ): Promise<HrCandidate[]> {
    return await this.hrCandidateRepository.find(filter);
  }

  @patch('/hr-candidates')
  async updateAll(
    @requestBody() obj: HrCandidate,
    @param.query.string('where') where?: Where,
  ): Promise<number> {
    return await this.hrCandidateRepository.updateAll(obj, where);
  }

  @del('/hr-candidates')
  async deleteAll(@param.query.string('where') where?: Where): Promise<number> {
    return await this.hrCandidateRepository.deleteAll(where);
  }

  @get('/hr-candidates/{id}')
  async findById(@param.path.string('id') id: string): Promise<HrCandidate> {
    return await this.hrCandidateRepository.findById(id);
  }

  @patch('/hr-candidates/{id}')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody() obj: HrCandidate,
  ): Promise<boolean> {
    return await this.hrCandidateRepository.updateById(id, obj);
  }

  @del('/hr-candidates/{id}')
  async deleteById(@param.path.string('id') id: string): Promise<boolean> {
    return await this.hrCandidateRepository.deleteById(id);
  }
}
