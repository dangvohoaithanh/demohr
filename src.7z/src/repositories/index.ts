export * from './hr-candidate.repository';
export * from './m-class.repository';
export * from './hr-test-template.repository';
export * from './hr-test-template-detail.repository';
export * from './hr-answer.repository';
export * from './hr-question.repository';
