import {
  DefaultCrudRepository, juggler,
  HasManyRepositoryFactory,
  repository,
} from '@loopback/repository';
import { HrQuestion, HrAnswer } from '../models';
import { HrAnswerRepository } from './hr-answer.repository'
import { inject } from '@loopback/core';

export class HrQuestionRepository extends DefaultCrudRepository<
  HrQuestion,
  typeof HrQuestion.prototype.id
  > {

  public hrAnswers: HasManyRepositoryFactory<typeof HrQuestion.prototype.id, HrAnswer>;
  constructor(
    @inject('datasources.ait') protected datasource: juggler.DataSource,
    @repository(HrAnswerRepository) hranswerRepository: HrAnswerRepository,
  ) {
    super(HrQuestion, datasource);
    this.hrAnswers = this._createHasManyRepositoryFactoryFor(
      'hrAnswers',
      hranswerRepository,
    );
  }


}
