import { Injectable } from '@angular/core';
import { HttpService } from '@app/core/http/http.service';
import { Observable } from 'rxjs';
import { API_URL, CLASS } from '@app/pages/hr/hr.constant';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { HrCandidate, HrCandidateDto } from '@app/models/hr/hr-candidate.model';
import { HrQuestion, HrQuestionDto } from '@app/models/hr/hr-question.model';
import { HrAnswer } from '@app/models/hr/hr-answer.model';
const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};
@Injectable({
  providedIn: 'root'
})


export class HrService {
  constructor(private httpService: HttpService) { }

  getHrCandidates(): Observable<any> {
    return this.httpService.get(API_URL.HR_CANDIDATE_GET);
  }

  getHrAnswersById(qscode: string){
    console.log(API_URL.HR_ANSWER_GET +'?filter[where][questioncode]=' + qscode);
    return this.httpService.get(API_URL.HR_ANSWER_GET +'?filter[where][questioncode]=' + qscode);
  }

  addHrCandidates(hrCandidate: HrCandidate): Observable<any> {
    return this.httpService.post(API_URL.HR_CANDIDATE_GET,hrCandidate, httpOptions);
  }

  addHrQuestions(hrQuestion: HrQuestion): Observable<any> {
    return this.httpService.post(API_URL.HR_QUESTION_GET,hrQuestion, httpOptions);
  }

  addHrAnswers(hrAnswer: HrAnswer): Observable<any> {
    return this.httpService.post(API_URL.HR_ANSWER_GET,hrAnswer, httpOptions);
  }

  updateHrCandidates(hrCandidate: HrCandidate, code: string): Observable<any> {
    return this.httpService.patch(API_URL.HR_CANDIDATE_GET + '/' + code, hrCandidate, httpOptions);
  }

  updateHrQuestions(hrQuestion: HrQuestion, code: string): Observable<any> {
    return this.httpService.patch(API_URL.HR_QUESTION_GET + '/' + code, hrQuestion, httpOptions);
  }

  updateHrAnswers(hrAnswer: HrAnswer, code: string): Observable<any> {
    return this.httpService.patch(API_URL.HR_ANSWER_GET + '/' + code, hrAnswer, httpOptions);
  }

  deleteHrAnswers(code: string){
    return this.httpService.delete(API_URL.HR_ANSWER_GET + '/' + code, httpOptions);
  }

  searchHrCandidates(context: any): Observable<any> {
    
    let sql = ''
    sql = '/hr-candidates'
    Object.keys(context).forEach(element => {
      if (context[element] !== '' && context[element]!=undefined) {
        if ('/hr-candidates' == sql) {
          sql += '?filter[where][and][0][' + element + ']=' + context[element];
        } else {
          sql += '&filter[where][and][0][' + element + ']=' + context[element];
        }
        
      }
    });
    return this.httpService.get(sql)
  }
  
  searchHrQuestions(context: any): Observable<any> {
    
    let sql = ''
    sql = '/hr-questions'
    Object.keys(context).forEach(element => {
      if (context[element] !== '' && context[element]!=undefined) {
        if ('/hr-questions' == sql) {
          sql += '?filter[where][and][0][' + element + ']=' + context[element];
        } else {
          sql += '&filter[where][and][0][' + element + ']=' + context[element];
        }
        
      }
    });
    return this.httpService.get(sql)
  }

  getHrTestTemplatesById(id: string){
    return this.httpService.get('/hr-test-template-details?filter[where][and][0][testTemplateId]='+id);
  }
}
