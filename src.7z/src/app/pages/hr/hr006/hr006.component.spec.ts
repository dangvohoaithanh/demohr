import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Hr006Component } from './hr006.component';

describe('Hr006Component', () => {
  let component: Hr006Component;
  let fixture: ComponentFixture<Hr006Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Hr006Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Hr006Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
