import { Component, OnInit, Inject } from '@angular/core';
import { HrQuestion, HrQuestionDto } from '@app/models/hr/hr-question.model';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatPaginator, MatTableDataSource, MatSort } from '@angular/material';
import { HttpService } from '@app/core/http/http.service';
import { API_URL, CLASS } from '@app/pages/hr/hr.constant';
import { MClass } from '@app/models/m-class.model';
import { Subscriber, Observable, forkJoin, merge } from 'rxjs';
import { HrService } from '@app/core/services/hr.service';
import { HrAnswer } from '@app/models/hr/hr-answer.model';
import { CurrencyIndex } from '@angular/common/src/i18n/locale_data';
import { findIndex } from 'rxjs/operators';
import { BaseSearchComponent } from '@app/shared';
import { mergeAll } from '../../../../../../node_modules/rxjs/operators';
import { componentFactoryName } from '@angular/compiler';
import { element } from 'protractor';

@Component({
  selector: 'app-hr007',
  templateUrl: './hr007.component.html',
  styleUrls: ['./hr007.component.scss']
})
export class Hr007Component implements OnInit {
  model: HrQuestion;
  details: HrAnswer[] = [];
  keys: any[] = [];
  keyCode: any[] = [];
  flagAdd: boolean = true;

  categorys: any;
  levels: any;
  categorySelected = '';
  levelSelected = '';
  image: string;
  activeFlag: boolean;
  selected: HrQuestion;
  temp = ''
  constructor(
    private httpService: HttpService,
    private hrService: HrService,
    public dialogRef: MatDialogRef<Hr007Component>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
  }

  ngOnInit() {


    const sub1 = this.httpService.get(API_URL.M_CLASS_GET).subscribe((res: any) => {
      this.categorys = res.filter((e: any) => e.precode === CLASS.QUESTION_CATEGORY);
      this.categorys.unshift(new MClass());
    });
    // get test template data
    const sub2 = this.httpService.get(API_URL.M_CLASS_GET).subscribe((res: any) => {
      this.levels = res.filter((e: any) => e.precode === CLASS.QUESTION_LEVEL);
      this.levels.unshift(new MClass());
    });
    // merge data before set name for position and test template
    merge([sub1, sub2]).subscribe(() => {
      this.httpService.get(API_URL.HR_QUESTION_GET).subscribe((res: any) => {
        res.forEach((element: any) => {
          element.categoryName = this.getCategoryName(element.category);
          element.levelName = this.getLevelName(element.level);
        });
      });
      if (this.data) {
        this.categorySelected = this.data.selected.category;
        this.levelSelected = this.data.selected.level;

      }
    })

    // let b=this.hrService.getHrCandidates()
    // let a =this.hrService.getHrAnswersById(this.data.code)
    // console.log(b)
    if (this.data) {
      this.hrService.getHrAnswersById(this.data.selected.code).subscribe((abc: any) => {
        this.details = abc;
        this.keys = Object.assign([], abc);


      });
    }


  }

  getCategoryName(code: string) {
    if (!this.categorys) {
      return;
    }
    const ret = this.categorys.filter((e: any) => e.code === code);
    if (ret && ret.length > 0) {
      return ret[0].name;
    }
  }

  getLevelName(code: string) {
    if (!this.levels) {
      return;
    }
    const ret = this.levels.filter((e: any) => e.code === code);
    if (ret && ret.length > 0) {
      return ret[0].name;
    }
  }

  delDetail(index: any) {
    if (this.details.length > 1){
      this.details.splice(index, 1);
      this.keyCode.push(this.details[index].code)
    }
  }


  //only mode new
  createDetail() {
    if (this.details.length < 1)
      this.details.splice(1, 0, new HrAnswer);
  }
  newDetail(index: any) {
    console.log(this.details)
    this.details.splice(index + 1, 0, new HrAnswer);
  }




  addAnswers(qscode: string) {
    this.dialogRef.afterClosed().subscribe(result => {
      for( var c = 0; c < this.keyCode.length; c++){
        this.hrService.deleteHrAnswers(this.keyCode[c])
      }
      for (var i = 0; i < this.keys.length; i++) {
        this.hrService.updateHrAnswers(this.keys[i], this.keys[i].code).subscribe()
      }
      for (var i = 0; i < this.details.length; i++) {
        for (var j = 0; j < this.keys.length; j++) {
          if (this.keys[j].code == this.details[i].code) {
            i++; j = -1;
            this.flagAdd = false;
            if (i == this.details.length) break;
          }
          else this.flagAdd = true;
        }
        if (i < this.details.length) {
          this.details[i].questioncode = qscode;
        }
        if (this.flagAdd == true) {
          this.hrService.addHrAnswers(this.details[i]).subscribe()
        }
      }
    })
  }
}
