import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Hr007Component } from './hr007.component';

describe('Hr007Component', () => {
  let component: Hr007Component;
  let fixture: ComponentFixture<Hr007Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Hr007Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Hr007Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
