import { Component, OnInit, Inject } from '@angular/core';
import { HrCandidate, HrCandidateDto } from '@app/models/hr';
import { MAT_DIALOG_DATA } from '@angular/material'
import { HttpService } from '@app/core/http/http.service';
import { API_URL, CLASS } from '@app/pages/hr/hr.constant';
import { MClass } from '@app/models/m-class.model';
import { Subscriber, Observable, forkJoin, merge } from 'rxjs';
import { HrService } from '@app/core/services/hr.service'
@Component({
  selector: 'app-hr005-input',
  templateUrl: './hr005-input.component.html',
  styleUrls: ['./hr005-input.component.scss']
})
export class Hr005InputComponent implements OnInit {

  model: HrCandidate;
  positions: any;
  positionSelected = '';
  templates: any;
  templateSelected = '';
  constructor(private httpService: HttpService, private hrService: HrService, @Inject(MAT_DIALOG_DATA) public data: any) {
  }

  ngOnInit() {
    this.model = new HrCandidateDto();
    const sub1 = this.httpService.get(API_URL.M_CLASS_GET).subscribe((res: any) => {
      this.positions = res.filter((e: any) => e.precode === CLASS.POSITION);
      this.positions.unshift(new MClass());
    });
    // get test template data
    const sub2 = this.httpService.get(API_URL.HR_TEST_TEMPLATE_GET).subscribe((res: any) => {
      this.templates = res;
      this.templates.unshift(new MClass());
    });
    // merge data before set name for position and test template
    merge([sub1, sub2]).subscribe(() => {
      this.httpService.get(API_URL.HR_CANDIDATE_GET).subscribe((res: any) => {
        res.forEach((element: any) => {
          element.positionName = this.getPositionName(element.position);
          element.testTemplateName = this.getTestTemplateName(element.testTemplate);
        });
      });
    });
    if (this.data) {
      this.positionSelected = this.data.selected.position;
      this.templateSelected = this.data.selected.testTemplate;
    }

  }
  

  getTestTemplateName(code: string) {
    if (!this.templates) {
      return;
    }
    const ret = this.templates.filter((e: any) => e.code === code);
    if (ret && ret.length > 0) {
      return ret[0].name;
    }
  }

  getPositionName(code: string) {
    if (!this.positions) {
      return;
    }
    const ret = this.positions.filter((e: any) => e.code === code);
    if (ret && ret.length > 0) {
      return ret[0].name;
    }
  }
}