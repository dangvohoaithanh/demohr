import { Component, OnInit, Inject } from '@angular/core';
import { HrTestTemplate } from '@app/models/hr';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { API_URL, CLASS } from '@app/pages/hr/hr.constant';
import { HttpService } from '@app/core/http/http.service';
import { HrTestTemplateDetail} from '@app/models/hr/hr-test-template-detail.model';
import { HrService } from '@app/core/services/hr.service'

@Component({
  selector: 'app-hr003-input',
  templateUrl: './hr003-input.component.html',
  styleUrls: ['./hr003-input.component.scss']
})
export class Hr003InputComponent implements OnInit {

  inputDetails: HrTestTemplateDetail[]= [];
  model: HrTestTemplateDetail;
  adDetail: number = 0;
  selectedCode: string;
  constructor(
    private httpService: HttpService,
    private hrService: HrService,
    public dialogRef: MatDialogRef<Hr003InputComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    
  ) { }

  ngOnInit() {
    // this.adDetail = new HrTestTemplateDetail();
    // this.adDetail.category = '';
    // this.adDetail.level = '';
    // this.adDetail.quantity = null;
    this.model = new HrTestTemplateDetail();
    console.log(this.model);
    if(this.data.code){
      this.hrService.getHrTestTemplatesById(this.data.code).subscribe((res: any) => {
        this.inputDetails = res;
        console.log(this.inputDetails);
      });
    } 
    else{
      this.inputDetails.push(this.model);
    }
    
  }
  
  selectCode(code: string): any{
    if(this.data.code){
      return this.selectedCode = this.data.code;
    }  
    return code;  
  }
  newDetail(): any{
    //this.inputDetails.unshift(this.adDetail);
    this.inputDetails.push(this.model);
    
  }
  down(n: number): any{
    this.adDetail = n;    
  }

  //Delete a test template detail 
  deleteModel(model: any){
    let x = this.inputDetails.findIndex( record => record === model);
    this.inputDetails.splice(x,1);
  }
}
