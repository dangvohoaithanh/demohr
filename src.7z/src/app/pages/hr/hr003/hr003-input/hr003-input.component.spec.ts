import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Hr003InputComponent } from './hr003-input.component';

describe('Hr003InputComponent', () => {
  let component: Hr003InputComponent;
  let fixture: ComponentFixture<Hr003InputComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Hr003InputComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Hr003InputComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
