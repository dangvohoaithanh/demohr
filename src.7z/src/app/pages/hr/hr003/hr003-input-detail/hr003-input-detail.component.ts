import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { HrTestTemplateDetail} from '@app/models/hr/hr-test-template-detail.model';
import { API_URL, CLASS } from '@app/pages/hr/hr.constant';
import { HttpService } from '@app/core/http/http.service';
import { MClass } from '@app/models/m-class.model';
import { Subscriber, forkJoin, merge,  Observable } from 'rxjs';
import { BaseSearchComponent } from '@app/shared';
import { HrService } from '@app/core/services/hr.service'


@Component({
  selector: 'app-hr003-input-detail',
  templateUrl: './hr003-input-detail.component.html',
  styleUrls: ['./hr003-input-detail.component.scss']
})
export class Hr003InputDetailComponent extends BaseSearchComponent implements OnInit {

  @Input() detailDownd: HrTestTemplateDetail;
  @Input() testTemplateId: string;
  @Output() detailUp = new EventEmitter<HrTestTemplateDetail>();
  
  model: HrTestTemplateDetail;
  //models: HrTestTemplateDetail[];
  categorys: any;
  categorySelected = '';
  levels: any;
  levelSelected = '';
  templateDetail: HrTestTemplateDetail;

  constructor(
    private httpService: HttpService,
    private hrService: HrService,
  ) {
    super();
   }

  /**
   * Initialize data
   *
   * @memberof Hr003InputDetailComponent
   */
  

  ngOnInit() {
    this.templateDetail = new HrTestTemplateDetail();
    // if(this.testTemplateId){
    //   this.hrService.getHrTestTemplatesById(this.testTemplateId).subscribe((res: any) => {
    //     this.models = res;
    //     console.log(this.models);
    //   });
    // }
    this.model = this.detailDownd;
    console.log(this.model);
    //this.detailUp.emit(3);
    //console.log(this.detailUp);
    //this.hrTestTemplateDetails.push(this.number);
    //this.detailDownd = new HrTestTemplateDetail();
    //this.detaillUp = this.detailDownd;
    // const sub = forkJoin(
    //   this.httpService.get(API_URL.M_CLASS_GET),
    //   this.httpService.get(API_URL.M_CLASS_GET)
    // ).subscribe(([req1, req2]) => {
    //   this.categorys = req1.filter((e: any) => e.precode === CLASS.QUESTION_CATEGORY);
    //   this.categorys.unshift(new MClass());
    //   this.levels = req2.filter((e: any) => e.precode === CLASS.QUESTION_LEVEL);
    //   this.levels.unshift(new MClass());
    //   console.log(req1);
    //   console.log(req2);
    // })

    // this.httpService.get(API_URL.HR_TEST_TEMPLATE_DETAIL_GET_BY_ID+'0000000000').subscribe((res: any) => {
    //       this.models = res;
    //      console.log(this.models);
    //     });
    // get category data
    const sub1 = this.httpService.get(API_URL.M_CLASS_GET).subscribe((res: any) => {
      this.categorys = res.filter((e: any) => e.precode === CLASS.QUESTION_CATEGORY);
      this.categorys.unshift(new MClass());
    });
    // get level data
    const sub2 = this.httpService.get(API_URL.M_CLASS_GET).subscribe((res: any) => {
      this.levels = res.filter((e: any) => e.precode === CLASS.QUESTION_LEVEL);
      this.levels.unshift(new MClass());
    });
    // merge data before set name for category and test level
    merge([sub1, sub2]).subscribe(() => {
      this.httpService.get(API_URL.HR_TEST_TEMPLATE_DETAIL_GET).subscribe((res: any) => {
        res.forEach((element: any) => {
          element.categoryName = this.getCategoryName(element.category);
          element.levelName = this.getLevelName(element.level);
        });
      });
    });
  }

    /**
   * Get name for category
   *
   * @param {string} code
   * @returns
   * @memberof Hr003InputDetailComponent
   */
  getCategoryName(code: string) {
    if (!this.categorys) {
      return;
    }
    const ret = this.categorys.filter((e: any) => e.code === code);
    if (ret && ret.length > 0) {
      return ret[0].name;
    }
  }

  /**
   * Get name for level
   *
   * @param {string} code
   * @returns
   * @memberof Hr003InputDetailComponent
   */
  getLevelName(code: string) {
    if (!this.levels) {
      return;
    }
    const ret = this.levels.filter((e: any) => e.code === code);
    if (ret && ret.length > 0) {
      return ret[0].name;
    }
  }

  deleteDetail(model: any){
    this.detailUp.emit(model);
  }
}
