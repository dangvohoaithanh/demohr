import { Component, OnInit, ViewChild } from '@angular/core';
import { HrTestTemplate} from '@app/models/hr/hr-test-template.model';
import { API_URL, CLASS } from '@app/pages/hr/hr.constant';
import { HttpService } from '@app/core/http/http.service';
import { MatPaginator, MatTableDataSource, MatDialog, MatSort } from '@angular/material';
import { BaseSearchComponent } from '@app/shared';
import { Subscriber, Observable, forkJoin, merge } from 'rxjs';
import { mergeAll } from '../../../../../node_modules/rxjs/operators';
import { Hr003InputComponent } from '@app/pages/hr/hr003/hr003-input/hr003-input.component';

@Component({
  selector: 'app-hr003',
  templateUrl: './hr003.component.html',
  styleUrls: ['./hr003.component.scss']
})
export class Hr003Component extends BaseSearchComponent implements OnInit {
    // Search condition
    model: HrTestTemplate;
    modelnew: HrTestTemplate;
    code: string;
    name: string;
    time: number;
    activeFlag: boolean;
    // Data table
    displayedColumns: any[] = [
      'code',
      'name',
      'time',
      'activeFlag'
    ];
    @ViewChild(MatPaginator) paginator: MatPaginator;
    @ViewChild(MatSort) sort: MatSort;
    dataSource: any = new MatTableDataSource<HrTestTemplate>([]);

  constructor(private httpService: HttpService, public dialog: MatDialog) {
    super();
   }

   
  /**
   * Initialize data
   *
   * @memberof Hr003Component
   */

  ngOnInit() {
    this.modelnew = new HrTestTemplate();
    this.model = new HrTestTemplate();
    // this.httpService.get(API_URL.HR_TEST_TEMPLATE_GET_BY_ID+'0000000000').subscribe((res: any) => {
    //   console.log(res);
    // });
    this.httpService.get(API_URL.HR_TEST_TEMPLATE_GET).subscribe((res: any) => {
      this.dataSource = new MatTableDataSource<HrTestTemplate>(res);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    });
    
  }

  openDialogNew() {
    const dialogRef = this.dialog.open(Hr003InputComponent,{
      width: '700px',
      data: this.modelnew
    });
   
  }
  openDialogUpdate(row: HrTestTemplate) {
    const dialogRef = this.dialog.open(Hr003InputComponent, {
      width: '700px',
      data: this.model = row
    });
   
  }
}
