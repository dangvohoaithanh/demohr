import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms'
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { TranslateModule } from '@ngx-translate/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { SharedModule } from '@app/shared';
import { MaterialModule } from '@app/material.module';
import { Hr005Component } from '@app/pages/hr/hr005/hr005.component';
import { HrRoutingModule } from '@app/pages/hr/hr.routing.module';
import { HrService } from '@app/core/services/hr.service';
import { HttpService } from '@app/core/http/http.service';
import { Hr005InputComponent } from '@app/pages/hr/hr005/hr005-input/hr005-input.component';
import { Hr006Component } from '@app/pages/hr/hr006/hr006.component';
import { Hr007Component } from '@app/pages/hr/hr006/hr007/hr007.component';
import { Hr003Component } from './hr003/hr003.component';
import { Hr003InputComponent } from '@app/pages/hr/hr003/hr003-input/hr003-input.component';
import { Hr003InputDetailComponent } from '@app/pages/hr/hr003/hr003-input-detail/hr003-input-detail.component';



@NgModule({
  imports: [
    CommonModule,
    ReactiveFormsModule,
    TranslateModule,
    SharedModule,
    FlexLayoutModule,
    MaterialModule,
    HrRoutingModule,
    FormsModule
  ],
  declarations: [
    Hr005Component, 
    Hr005InputComponent, 
    Hr003Component,
    Hr003InputComponent,
    Hr003InputDetailComponent,
    Hr006Component,
    Hr007Component,

  ],
  providers: [HrService, HttpService]
})
export class HrModule {}
