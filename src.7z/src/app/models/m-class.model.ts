import { Deserializable } from '@app/models/deserializable.model';

export class MClass implements Deserializable {
  precode: string;
  code: string;
  name: string;

  constructor() {}

  deserialize(input: any) {
    Object.assign(<any>this, input);
    return this;
  }
}
