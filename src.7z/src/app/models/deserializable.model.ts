export interface Deserializable {
  deserialize(input: any): this;
}
