export {HrCandidate} from '@app/models/hr/hr-candidate.model';
export {HrCandidateDto} from '@app/models/hr/hr-candidate.model';
export {HrTestTemplate} from '@app/models/hr/hr-test-template.model';
export {HrTestTemplateDetail} from '@app/models/hr/hr-test-template-detail.model';


