import { Deserializable } from '@app/models/deserializable.model';

export class HrTestTemplate implements Deserializable {
  code: string;
  name: string;
  email: string;
  time: number;
  activeFlag: boolean;
  constructor() {}

  deserialize(input: any) {
    Object.assign(<any>this, input);
    return this;
  }
}
